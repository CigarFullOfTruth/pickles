Thank's For Your Purchase! :)

Made and sold by: Copeman#1800

*License Agreement*

(1).Permission is granted for personal rust server use on servers owned by you, the customer.
(2).Permission is not granted for commercial use, distribution/sharing, editing/modification, or re-sale." or create your own.
(3).Any Attempted to resale or claim this work as your will result in a ban from my discord aswell as reported to other map maker's
(4).YOU MAY NOT REPOST THIS OR GIVE IT AWAY TO ANYONE
(5).IF I FIND THIS ON A SERVER THAT DID NOT BUY IT I WILL SUBMIT A DMCA TAKEDOWN WITH YOUR SERVICE PROVIDER


*Place's To Get My Prefab's/Map's*

My Discord: https://discord.gg/ScEthGWErB

RustWorkShop: https://rustworkshop.space/members/copeman365.715/#resources

MyVector.xyz: https://www.myvector.xyz/index.php?members/copeman.117/#resources


*File Info*
This Is Arena 22 It's Great For 1v1 2v2 or 3v3 or even capture the flag



Please Make Sure To Click Apply On These When Placing In Rust Edit:
(1).Alpha Mask
(2).Height Mask
(3).Splat Mask

enjoy! 


*Requirements*
-In order to place this monument on your map you will need RustEdit in order to do so. (https://www.rustedit.io/)
-Must have oxide installed on your server (https://umod.org/)
-Must have the rust edit .dll installed in your RustDedicated/Managed folder (https://github.com/k1lly0u/Oxide.Ext.RustEdit)


-To add one of my prefabs to your existing map make sure you first drag and drop all of the .prefab files in your "Custom Prefabs" folder located in your RustEdit install directory like this "C:\Program Files (x86)\RustEdit\CustomPrefabs"
-Once you've dropped the .prefabs in there you can then open up RustEdit and either create a new world or load your current server's .map file
-Once your map loads up, tap on the "Prefabs" tab in the top right UI and click on the "Custom" section from the window it opens up.
-Now you can just drag and drop that prefab wherever you want to get your map created!
-Additionally some of my prefabs do have terrain modification so in the bottom section of the prefab info make sure you click "Apply Terrain Height, Splat, etc" So nothing is floating or looking strange. 

