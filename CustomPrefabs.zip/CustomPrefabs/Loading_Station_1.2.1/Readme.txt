
   __                _               
  /__\ ___  __ _  __| |   /\/\   ___ 
 / \/// _ \/ _` |/ _` |  /    \ / _ \
/ _  \  __/ (_| | (_| | / /\/\ \  __/
\/ \_/\___|\__,_|\__,_| \/    \/\___|


Thank you for purchasing my monument "Loading Station". (Version 1.0)
I hope it meet your expectations and you, your friends and the other players on your server have fun exploring something new.


Short explanation and lore behind the monument:
-----------------------------------------------
The scene shows a rotten loading station surrounded by a little forest, which was used to reload goods from trains to trucks and trucks to trains in the good old times.
But it isn´t so leave as it seems. A group of scientists was using the loading station to reload weaponry to a train and send it to the compound as suddenly one of the
rusty structures collapsed and buried an armored truck among themselves.
It´s your task to clear the area of scientists and find a way to open the armored truck to gain access to the weapons inside.
While exploring the area you will see, you and the scientist are not the only ones who used the loading station for their own purposes.


This monument includes:
-----------------------
* Two versions of the "Loading Station".
  First one is the monument version for normal use on your server with all loot, effects, IO elements and levels you can go to
  The second one is the arena version for using with the deathmatch or gungame plugins. Reduced prefab count, reduced effects, no sewer system and no loot boxes/barrels plus invisible colliders around the area
* Prefab count monument: 4820
  Prefab count arena: 1819
* Monument: alpha mask, biome mask, height mask, texture mask, topology mask
  Arena: texture mask, topology mask
* custom loot (custom loot presets included if you have trouble loading the custom loot)
* custom vending machine (custom vending machine preset included if you have trouble loading the loot inside of it)
* custom CCTVs
* scientist NPCs
* many custom prefabs
* path around the area for optional bradley spawns (no bradleys included)
* hidden "easteregg" crate
* a more demanding door puzzle as the usual greencard/bluecard/redcard puzzles
* little safezone inside the monument (you just have to find it)
* fully accessible. You can climb any building and travel trough the sewer system
* free updates for all customers
* live support if you have trouble with anything related to this monument


How to use:
-----------
1. After extracting the package file, there are different folders.
2. Copy the content of the folder "Monument" to ../RustEdit/CustomPrefabs/
3. Copy the content of the folder "LootPresets" to ../RustEdit/LootPresets/
4. Copy the content of the folder "VendingPresets" to ../RustEdit/VendingPresets/
5. Step 3 and 4 are just needed as backup in case the loot- and vending presets are not working correctly. So you can assign the presets to all loot containers and vending machines
6. Place the prefab in RustEdit and use the mask options to set terrain, height, biome, aso.
7. In most cases you have to correct the alpha mask. It´s in issue I can´t prevent. There are 3 entrances to the sewer. Make sure all entrances have a working alpha mask.
8. In some cases you have to adjust the height a little. Sometimes the height mask isn´t 100% correct.
9. Don´t move the IO elements if it isn´t needed to prevent breaking the electrical connections.
10. The armored truck can be opened with two fuses, a switch and a RF transmitter. The frequency is "4178" (also shown on a blackboard in a room). You can change the frequency at the RF Receiver. Remember to change the frequency shown on the blackboard aswell.
11. Camera Codes: LOADINGSTATION01
		  LOADINGSTATION02
		  LOADINGSTATION03
	  	  LOADINGSTATION04
		  LOADINGSTATION05



Questions? Suggestions? Found bugs? Need help with this monument?
Contact me via Discord.

Abracadaver Rust Prefabs: https://discord.gg/dVd5bDU
Pravum Rust Custom Designs: https://discord.gg/XSk42U9



Credits:
--------
Testers:		PRAVUM (https://discord.gg/XSk42U9)
			SHARLIMAR
			LEVINTOS
			NACRON (https://discord.gg/CKFFNBz)

Scraptrain prefab by:	JAYSRIPS (https://discord.gg/sAm7Vf9)