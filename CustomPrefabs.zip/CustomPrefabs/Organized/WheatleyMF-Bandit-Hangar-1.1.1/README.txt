﻿Thank you for download! <3
I hope you will enjoy this prefab.

Update 1.1.1, August 8th 2020:
• Roof prefab fixes (RustEdit >1.23 compatibility fix)

INSTALLING:
1. Open your RustEdit root directory. 
2. Find the "CustomPrefabs" folder.
3. Drag and drop all files (except for this .txt file) in that folder.

USING:
If custom prefab was properly installed, just search for "Bandit Hangar August8" in Prefabs List menu. Double click on it and it will be spawned on your map.

PREFAB MODIFIERS:
When custom monument is selected, on very bottom of "Transform Tool" menu you'll find a thing called PREFAB MODIFIERS.
When you have decided where are you going to place this monument, you'll need to apply all of these modifiers.

TERMS OF USE:
tl;dr - you can use this prefab however and wherever you want, but using it in paid prefabs/maps is not allowed. And you can't sell it, obviously.

    • You can use it in your prefabs/maps as long as they're intended to be published for free. (crediting me will be appreciated!)
    • You can use it on any kind of server without asking for permission.
    • You CAN share this prefab to other users and upload it to other websites, but you CAN'T sell it. When reuploading, crediting me is required.

CONTACT:
Got any questions? Suggestions? Contact me!
    DISCORD: WheatleyMF#5798
    EMAIL: misterwheatley6@gmail.com 
    TWITTER: @wheatleymf 

MORE CONTENT:
I have more monuments, prefabs and other stuff for free at my website.
http://wheatleymf.net/projects 

© 2019-2020