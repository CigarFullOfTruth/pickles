﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Facepunch.Extend;
using Newtonsoft.Json;
using Oxide.Core;
using Oxide.Game.Rust.Cui;
using ProtoBuf;
using UnityEngine;

//using System.IO;

namespace Oxide.Plugins
{
    [Info("Reactive Targets", "Yoshy", "0.1")]
    class ReactiveTargets : RustPlugin
    {
        HashSet<ReactiveTarget> targets = new HashSet<ReactiveTarget>();
        private const string TargetPerm = "ReactiveTargets.use";
        float health = 100f;

        void Loaded()
        {
            permission.RegisterPermission(TargetPerm, this);

            foreach (ReactiveTarget target in BaseEntity.serverEntities.OfType<ReactiveTarget>())
            {
                if (target.OwnerID == 0)
                {
                    targets.Add(target);
                    target.knockdownHealth = config.health;
                    target.skinID = config.skin;
                    target.SendNetworkUpdate();
                }
            }
        }


        [ChatCommand("target")]
        void TargetHealth(BasePlayer player, string command, string[] args, HitInfo info)
        {
            if (!player.IPlayer.HasPermission(TargetPerm)) { player.ChatMessage("missing perms"); return; }

            if (args.Count() == 0)
            {
                player.ChatMessage("<size=19><color=#F10E0E>invalid format,  /target health (number),  /target skin (skinid),  /target reset (number)</size></color>");
            }

            if (args[0] == "health" && args[1].Count() > 0)
            {
                health = (float)args[1].ToInt();

                foreach (ReactiveTarget target in targets)
                {
                    target.knockdownHealth = health;
                }

                config.health = health;
                SaveConfig();

                player.ChatMessage($"<size=19><color=#FFD700>targets health set to {args[1]}</size></color>");
            }

            if(args[0] == "skin" && args[1].Count() > 0)
            {
                ulong skinid = (ulong)args[1].ToInt();

                foreach (ReactiveTarget target in targets)
                {
                    target.skinID = skinid;
                    target.SendNetworkUpdate();
                    target.knockdownHealth = config.health;
                }

                config.skin = skinid;
                SaveConfig();

                player.ChatMessage($"<size=19><color=#FFD700>targets skinid set to {args[1]}</size></color>");
            }

            if (args[0] == "reset" && args[1].Count() > 0)
            {
                float reset = (float)args[1].ToInt();

                config.reset = reset;
                SaveConfig();

                player.ChatMessage($"<size=19><color=#FFD700>targets reset time set to {args[1]}</size></color>");
            }
        }

        object OnButtonPress(PressButton button, BasePlayer player)
        {
            if (button.OwnerID != 0) return null;
            if (config.health == 100) return null;

            timer.Once(0.5f, () =>
            {
                foreach (ReactiveTarget target in targets)
                {
                    target.knockdownHealth = config.health;
                }
            });

            return null;
        }

        private void OnEntityTakeDamage(ReactiveTarget reactiveTarget, HitInfo info)
        {
            if (reactiveTarget.OwnerID != 0) return;

            NextFrame(() =>
            {
                if (reactiveTarget.IsKnockedDown())
                {
                    reactiveTarget.CancelInvoke(reactiveTarget.ResetTarget);
                    if (config.reset <= 0) return;

                    timer.Once(config.reset, () =>
                    {
                        reactiveTarget.ResetTarget();
                        reactiveTarget.knockdownHealth = config.health;
                    });
                }
            });
        }

        #region config
        private Configuration config;
        public class Configuration
        {
            [JsonProperty(PropertyName = "knockdown health")]
            public float health = 100f;

            [JsonProperty(PropertyName = "default skin")]
            public ulong skin = 1;

            [JsonProperty(PropertyName = "target reset time")]
            public float reset = 0;
        }

        protected override void LoadConfig()
        {
            base.LoadConfig();
            try
            {
                config = Config.ReadObject<Configuration>();
                if (config == null) throw new Exception();
                SaveConfig();
            }
            catch
            {
                PrintError("Your configuration file contains an error. Using default configuration values.");
                LoadDefaultConfig();
            }
        }

        protected override void SaveConfig() => Config.WriteObject(config);

        protected override void LoadDefaultConfig() => config = new Configuration();

        #endregion
    }
}
