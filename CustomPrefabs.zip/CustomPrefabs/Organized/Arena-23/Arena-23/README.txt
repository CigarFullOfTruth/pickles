Thank's For Your Purchase! :)

Made and sold by: Copeman#1800

My Discord: https://discord.gg/ScEthGWErB

Any Attempted to resale or claim this work as your will result in a ban from my discord aswell as reported to other map maker's

YOU MAY NOT REPOST THIS OR GIVE IT AWAY TO ANYONE

IF I FIND THIS ON A SERVER THAT DID NOT BUY IT I WILL SUBMIT A DMCA TAKEDOWN WITH YOUR SERVICE PROVIDER

Arena 23 is a small 1v1 or 3v3 prefab i created for my pvp server, but ive decided why keep it all to myself

enjoy! 

side note, you may make any changes to it but you cant repost it
