Thank you for downloading this Rust Custom Monument (1k Objects Aprox)

This is a missile silo based on the Titan II

If you place it with the ground floor roof level with the water table you
get a good effect of a semi flooded monument. You will find fuses and green
to red keycards required to make it to the end and pockets of radiation
along with the scientists to hinder you.


Finally, please make yourself aware of the TOS-Restrictions for use.


Thanks
Niko