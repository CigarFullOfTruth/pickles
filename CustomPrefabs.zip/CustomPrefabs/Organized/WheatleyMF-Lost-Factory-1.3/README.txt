﻿Thank you for downloading! <3
I hope you will enjoy this prefab.

INSTALLING:
1. Open your RustEdit root directory. 
2. Find the "CustomPrefabs" folder.
3. Drag and drop all files (except for this .txt file) in that folder.

[HDRP BACKPORT] 1.3 – April 13th, 2020:
This update is an early preparation for upcoming May 6th update that will overhaul nearly all visual aspects of Rust. This will look different on pre-May versions of the game, perhaps even worse than 1.2.3.

• Splat overhaul for HDRP backport update
• Removed nearly all custom foliage prefabs since Rust has a pretty neat and dense procedural foliage now, should slightly help with the performance
• Fixed one of doors having bugged colliders
• Replaced bandit camp fog with a different fog volume
• Added a small custom rock formation
• Some very minor decor tweaks

USING:
If custom prefab was properly installed, just search for "Lost Factory v1 3" in Prefabs List menu. Double click on it and it will be spawned on your map.

PREFAB MODIFIERS:
When custom monument is selected, on very bottom of "Transform Tool" menu you'll find a thing called PREFAB MODIFIERS.
When you have decided where are you going to place this monument, you'll need to apply all of these modifiers.

TERMS OF USE:
tl;dr - you can use this prefab however and wherever you want, but using it in paid prefabs/maps is not allowed. And you can't sell it, obviously.

    • You can use it in your prefabs/maps as long as they're intended to be published for free. (crediting me will be appreciated!)
    • You can use it on any kind of server without asking for permission.
    • You CAN share this prefab to other users and upload it to other websites, but you CAN'T sell it. When reuploading, crediting is required.

CONTACT:
Got any questions? Suggestions? Contact me!
    DISCORD: WheatleyMF#5798
    EMAIL: host@wheatleymf.net
    TWITTER: @wheatleymf 

MORE CONTENT:
I have more monuments, prefabs and other stuff for free at my website.
http://wheatleymf.net/projects 

© 2019-2021