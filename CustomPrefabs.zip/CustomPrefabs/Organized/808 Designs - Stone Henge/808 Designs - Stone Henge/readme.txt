THANK YOU FOR DOWNLOADING MY PREFAB! PLEASE CONSIDER GIVING A RATING OR EVEN A THUMBS UP. THANKS
====================================================================

INSTALLING:
• Open your RustEdit folder
• Find "CustomPrefabs" folder and open it
• Select "808 Designs - Stone Henge" folder from this .ZIP archive and drag it into "CustomPrefabs" folder

Note! You will need the latest versions of Oxide and Oxide.Ext.RustEdit.dll installed on your server.

=====================================================================

USING:
If you have installed this pack correctly, it will show up in "Custom Prefab List" menu.

=====================================================================

TERMS OF USE:
Permission is granted for personal rust server use on servers owned by you, the downloader.

Permission is not granted for commercial use, distribution/sharing, editing/modification, or re-sale.

Note: Please make sure your work/map(and mine) is password protected on Rust Edit

=====================================================================

CONTACT:
Do you have any issues? 

    DISCORD: ! smoke.uk#1373