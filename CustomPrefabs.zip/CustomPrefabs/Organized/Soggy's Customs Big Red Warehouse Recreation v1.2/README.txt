This prefab features the Escape from Tarkov Big Red Warehouse location from the map customs. I have taken special care to ensure that the monument is desirable to loot and has thoughtful puzzles and combat scenarios. The inside is pretty much 1:1 faithful to the original, and I took a little liberty when designing the outskirts.

~ 2190 PREFABS IN THE MONUMENT
REDCARD
BLUECARD
MODERATE TO HIGH AMOUNT OF REACHABLE LOOT
CHINOOK DROP ZONE INCLUDED

Instructions for install below.

I am available for commissions and custom prefab/map creation, just message me where you got this file to get in touch with me!

_______________TERMS AND CONDITIONS / LICENSE____________________________________
This prefab is available for FREE for all personal and commercial use in Rust maps and servers, under the condition that you DO NOT REMOVE the credits sign placed in the prefab. 
If used as a monument/point of interest on a server, you can make the server public, as well as make money from it. 
If used as part of a custom downloadable map, you can make it public if it is free. For a paid map, please always contact me beforehand so we can work something out.

You CANNOT, however, make available or sell the prefab unmodified and by itself, or pass it off as your own!

Credits in server description etc. are appreciated but not necessary, as well as notifying me when you use the monument on a public server or map.

Modified releases of the prefab by itself are handled on a case by case basis, under the condition of full credits to me (sign in the map, and written). Message me to discuss that.
_________________________________________________________________________________

Due to limitations of RUST and Rustedit, there are some caveats to using this map:
‣ There might be alpha holes on the perimeter of the saved prefab circle. There's nothing I can do about that as it is a Rustedit bug, so keep an eye out for hole in terrain. They should be easily fixable with the alpha eraser, tho.
‣ You MIGHT need to take a look at the terrain to make sure that the heightmap apply feature didn't leave holes anywhere. Same issue as above.
‣ The monument marker isn't saved into the prefab. Rustedit limitation, I'm afraid. How to add it below!
‣ The RustEdit Oxide plugin needs to be used for loot and puzzles, more on that below!

PREREQUISITES:
In order for the keycard puzzles and the loot respawns to work, you will NEED to have the RustEdit Oxide plugin installed. Look for tutorials how to do it. (It's also possible on Vanilla servers, they allow plugins that don't alter gameplay!)
Download it here: https://github.com/k1lly0u/Oxide.Ext.RustEdit
Not having it is severly discouraged, as you would manually need to delete the keycard doors, some prefabs would be missing and most of the features won't work.

INSTALLATION GUIDE:
‣ Put the folder found inside of this zip into the CustomPrefab folder in the Rustedit install location
‣ Start RustEdit and open up your map first
‣ Open the prefab list and drag the Monument in
‣ If necessary drag it down to be level with terrain
‣ Apply Heightmap, Splat, Topology, Alpha and Paths
‣ Add a Monument Marker prefab at the place where the small blue sphere in the courtyard is, and name it "Customs Warehouse". Video tutorial on that coming soon on my channel.
‣ Save your map, and load it into your server. Have fun!

For more support, just ask me, I'll be happy to help!

